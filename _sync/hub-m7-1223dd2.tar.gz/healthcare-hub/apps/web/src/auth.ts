/**
 * Auth client abstraction. Tokens are held in memory only - never localStorage (SECURITY_COMPLIANCE §1).
 *
 *  - MockAuthClient: development against the dev-only mock OIDC server (apps/api `dev:oidc`).
 *  - Production: Microsoft Entra External ID via OIDC Authorization Code + PKCE (ADR-0003).
 *    That client is wired in once the Entra tenant exists (open question tracked in DECISIONS.md);
 *    the app depends only on this interface.
 */
export interface AuthClient {
  /** Returns a valid access token, signing in if needed. */
  getToken(): Promise<string>;
  signOut(): void;
  isSignedIn(): boolean;
}

export class MockAuthClient implements AuthClient {
  private token: string | null = null;
  constructor(
    private readonly baseUrl: string,
    private readonly devUser: string,
  ) {}

  async getToken(): Promise<string> {
    if (this.token) return this.token;
    const res = await fetch(`${this.baseUrl}/token?user=${encodeURIComponent(this.devUser)}`);
    if (!res.ok) throw new Error('Dev sign-in failed (is the mock OIDC server running?)');
    const body = (await res.json()) as { access_token: string };
    this.token = body.access_token;
    return this.token;
  }
  signOut(): void {
    this.token = null;
  }
  isSignedIn(): boolean {
    return this.token !== null;
  }
}

export function createAuthClient(): AuthClient {
  if (import.meta.env.PROD) {
    throw new Error('Production sign-in (Entra External ID) is not configured yet');
  }
  return new MockAuthClient(
    import.meta.env.VITE_MOCK_OIDC_URL ?? 'http://localhost:4010',
    import.meta.env.VITE_DEV_USER ?? 'manager',
  );
}
