import { Link, Outlet } from '@tanstack/react-router';
import { StatusBadge } from '@hub/ui';
import { NAV_ITEMS } from '../nav.js';
import { useApp } from './AppContext.js';

const londonDate = new Intl.DateTimeFormat('en-GB', {
  dateStyle: 'full',
  timeZone: 'Europe/London',
});
const londonTime = new Intl.DateTimeFormat('en-GB', {
  timeStyle: 'short',
  timeZone: 'Europe/London',
});

export function Shell() {
  const { me, orgId, setOrgId, refresh, lastUpdated, sourceOk } = useApp();
  const orgs = [
    ...new Map(me.memberships.map((m) => [m.organisationId, m.organisationName])).entries(),
  ];
  const activeOrg = orgs.find(([id]) => id === orgId)?.[1];

  return (
    <div className="flex min-h-screen flex-col">
      <a href="#main" className="sr-only focus:not-sr-only focus:absolute focus:bg-white focus:p-2">
        Skip to main content
      </a>
      <header className="flex flex-wrap items-center gap-4 border-b border-slate-300 bg-white px-4 py-3">
        <span className="text-lg font-bold">Healthcare Hub</span>
        <div className="flex items-center gap-2">
          <label htmlFor="org-switcher" className="text-sm font-medium">
            Organisation
          </label>
          <select
            id="org-switcher"
            className="rounded border border-slate-500 bg-white px-2 py-1"
            value={orgId ?? ''}
            onChange={(e) => setOrgId(e.target.value)}
          >
            {orgs.map(([id, name]) => (
              <option key={id} value={id}>
                {name}
              </option>
            ))}
          </select>
        </div>
        <nav aria-label="Breadcrumb" className="text-sm text-slate-700">
          <ol className="flex gap-1">
            <li>{activeOrg ?? 'No organisation'}</li>
            <li aria-hidden="true">/</li>
            <li>All locations</li>
            <li aria-hidden="true">/</li>
            <li aria-current="page">All services</li>
          </ol>
        </nav>
        <div className="ml-auto flex flex-wrap items-center gap-3 text-sm">
          <time dateTime={new Date().toISOString()}>{londonDate.format(new Date())}</time>
          <button
            type="button"
            onClick={refresh}
            className="rounded border border-slate-500 px-3 py-1 hover:bg-slate-100"
          >
            Refresh
          </button>
          <span>Last updated {lastUpdated ? londonTime.format(lastUpdated) : '—'}</span>
          {sourceOk ? (
            <StatusBadge status="GREEN" reason="sources available" />
          ) : (
            <StatusBadge status="RED" reason="source unavailable" />
          )}
        </div>
      </header>
      <div className="flex flex-1">
        <nav aria-label="Primary" className="w-56 shrink-0 border-r border-slate-300 bg-white p-3">
          <ul className="space-y-1">
            {NAV_ITEMS.map((item) => (
              <li key={item.to}>
                <Link
                  to={item.to}
                  activeOptions={{ exact: item.to === '/' }}
                  className="block rounded px-3 py-2 hover:bg-slate-100"
                  activeProps={{
                    'aria-current': 'page',
                    className: 'block rounded px-3 py-2 bg-slate-200 font-semibold',
                  }}
                >
                  {item.label}
                </Link>
              </li>
            ))}
          </ul>
        </nav>
        <main id="main" className="flex-1 p-6" tabIndex={-1}>
          <Outlet />
        </main>
      </div>
    </div>
  );
}
