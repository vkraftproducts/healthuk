/// <reference types="vite/client" />
interface ImportMetaEnv {
  readonly VITE_MOCK_OIDC_URL?: string;
  readonly VITE_DEV_USER?: string;
}
