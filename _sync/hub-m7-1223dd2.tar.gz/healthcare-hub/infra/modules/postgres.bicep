param prefix string
param location string
param adminLogin string
@secure()
param adminPassword string
param skuName string

resource pg 'Microsoft.DBforPostgreSQL/flexibleServers@2024-08-01' = {
  name: '${prefix}-pg'
  location: location
  sku: { name: skuName, tier: 'Burstable' }
  properties: {
    version: '16'
    administratorLogin: adminLogin
    administratorLoginPassword: adminPassword
    storage: { storageSizeGB: 64 }
    backup: { backupRetentionDays: 35, geoRedundantBackup: 'Enabled' } // PITR 35 days, geo copy in UK West
    highAvailability: { mode: 'Disabled' } // zone-redundant HA is the post-pilot upgrade path
    authConfig: { passwordAuth: 'Enabled', activeDirectoryAuth: 'Disabled' }
  }
}

resource db 'Microsoft.DBforPostgreSQL/flexibleServers/databases@2024-08-01' = {
  parent: pg
  name: 'hub'
}

// btree_gist is required for the allocation exclusion constraint (M6).
resource exts 'Microsoft.DBforPostgreSQL/flexibleServers/configurations@2024-08-01' = {
  parent: pg
  name: 'azure.extensions'
  properties: { value: 'BTREE_GIST,PGCRYPTO', source: 'user-override' }
}

output fqdn string = pg.properties.fullyQualifiedDomainName
