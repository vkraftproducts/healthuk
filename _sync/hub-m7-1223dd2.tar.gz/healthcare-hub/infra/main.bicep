// Healthcare Hub - lean pilot footprint (docs/ARCHITECTURE.md §5). UK South primary.
// STATUS: written in M0, not yet compiled or deployed (no Azure access during the build).
// Run `az bicep build -f infra/main.bicep` and a what-if before first use.
targetScope = 'resourceGroup'

@description('Environment name, used in resource names.')
param env string
param location string = 'uksouth'
@description('Postgres administrator login (password is generated into Key Vault by the deploy job).')
param pgAdminLogin string = 'hubadmin'
@secure()
param pgAdminPassword string
@description('Daily cap (GB) for Log Analytics ingestion - keeps the pilot inside budget.')
param logDailyCapGb int = 1

var prefix = 'hub-${env}'

module monitoring 'modules/monitoring.bicep' = {
  name: 'monitoring'
  params: { prefix: prefix, location: location, dailyCapGb: logDailyCapGb }
}

module storage 'modules/storage.bicep' = {
  name: 'storage'
  params: { prefix: replace(prefix, '-', ''), location: location }
}

module keyvault 'modules/keyvault.bicep' = {
  name: 'keyvault'
  params: { prefix: prefix, location: location }
}

module postgres 'modules/postgres.bicep' = {
  name: 'postgres'
  params: {
    prefix: prefix
    location: location
    adminLogin: pgAdminLogin
    adminPassword: pgAdminPassword
    // Burstable B1ms for staging, B2s for production (set in params).
    skuName: env == 'prod' ? 'Standard_B2s' : 'Standard_B1ms'
  }
}

output storageAccountName string = storage.outputs.name
output keyVaultName string = keyvault.outputs.name
output postgresHost string = postgres.outputs.fqdn
output appInsightsConnectionString string = monitoring.outputs.appInsightsConnectionString
