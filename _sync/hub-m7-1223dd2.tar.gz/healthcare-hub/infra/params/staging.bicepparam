using '../main.bicep'

param env = 'staging'
param location = 'uksouth'
// pgAdminPassword is supplied by the deploy job from Key Vault / a secret, never committed.
param pgAdminPassword = readEnvironmentVariable('PG_ADMIN_PASSWORD')
