using '../main.bicep'

param env = 'prod'
param location = 'uksouth'
param pgAdminPassword = readEnvironmentVariable('PG_ADMIN_PASSWORD')
