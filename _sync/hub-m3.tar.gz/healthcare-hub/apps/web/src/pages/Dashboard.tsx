import { DataTable, StatusBadge } from '@hub/ui';
import { useApp } from '../shell/AppContext.js';

// KPI tiles are counted separately and never merged (PRD §4.2). Real counts arrive in M5; until
// then the tiles show an explicit "not connected" state rather than a misleading zero.
const TILES = ['Overdue tasks', 'Due in 30 days', 'Blocked vehicles', 'Jobs today'] as const;

export function Dashboard() {
  const { me, orgId } = useApp();
  const canView = me.permissions.includes('dashboard.view');
  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>
      {!orgId ? (
        <p role="status">Select an organisation to continue.</p>
      ) : !canView ? (
        <p role="alert">You do not have permission to view the dashboard for this organisation.</p>
      ) : (
        <>
          <section aria-label="Key figures" className="grid grid-cols-2 gap-4 lg:grid-cols-4">
            {TILES.map((t) => (
              <div key={t} className="rounded border border-slate-300 bg-white p-4">
                <div className="text-sm text-slate-700">{t}</div>
                <div className="mt-1 text-3xl font-bold" aria-label={`${t}: not connected yet`}>
                  —
                </div>
                <div className="mt-2">
                  <StatusBadge status="GREY" reason="not connected yet" />
                </div>
              </div>
            ))}
          </section>
          <section
            aria-labelledby="actions-h"
            className="rounded border border-slate-300 bg-white p-4"
          >
            <h2 id="actions-h" className="mb-2 text-lg font-semibold">
              Action required
            </h2>
            <DataTable
              caption="Action required"
              columns={[
                { key: 'item', header: 'Item', cell: (r: Row) => r.item },
                { key: 'owner', header: 'Owner', cell: (r: Row) => r.owner },
                { key: 'deadline', header: 'Deadline', cell: (r: Row) => r.deadline },
                { key: 'state', header: 'State', cell: (r: Row) => r.state },
              ]}
              rows={[]}
              rowKey={(r: Row) => r.item}
              emptyMessage="Requirements, evidence and alerts arrive in Milestone M2; the action list is built in M5."
            />
          </section>
          <p className="text-sm text-slate-700">
            Internal measures on this dashboard are not CQC ratings.
          </p>
        </>
      )}
    </div>
  );
}

interface Row {
  item: string;
  owner: string;
  deadline: string;
  state: string;
}
