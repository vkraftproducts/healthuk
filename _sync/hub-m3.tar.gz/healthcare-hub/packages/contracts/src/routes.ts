import { z } from 'zod';
import { AuditListResponse, VerifyChainResponse } from './audit.js';
import { HealthResponse, ReadyResponse } from './health.js';
import { MeResponse } from './me.js';
import { Problem } from './problem.js';
import {
  ActivityDto,
  AdminUserDto,
  LocationDto,
  OrganisationDto,
  PermissionDto,
  RoleDto,
  ServiceDto,
  SettingsResponse,
  SupportGrantDto,
} from './admin.js';
import {
  AlertDto,
  DownloadResponse,
  EvidenceVersionDto,
  InstanceDetailDto,
  InstanceDto,
  InstancePage,
  LinkResponse,
  TemplateDto,
  TemplateVersionDto,
  UploadResponse,
} from './requirements.js';
import {
  CorrectionDto,
  MatrixDto,
  MyStaffDto,
  ReadinessDto,
  RoleApprovalDto,
  RoleRequirementDto,
  RestrictionDto,
  StaffClearanceDto,
  StaffDetailDto,
  StaffDto,
  StaffPage,
  StaffRecordDto,
} from './staff.js';
import { z as zz } from 'zod';
import { uuid } from './common.js';

const list = <T extends zz.ZodType>(t: T) => zz.object({ data: zz.array(t) });

export interface RouteDef {
  method: 'get' | 'post' | 'put' | 'patch' | 'delete';
  path: string; // relative to /api/v1 unless `unversioned`
  summary: string;
  response: z.ZodType;
  unversioned?: boolean;
  public?: boolean;
}

/** Registry used to generate OpenAPI. Add every endpoint here with its zod schemas. */
export const routes: Record<string, RouteDef> = {
  healthz: {
    method: 'get',
    path: '/healthz',
    summary: 'Liveness',
    response: HealthResponse,
    unversioned: true,
    public: true,
  },
  readyz: {
    method: 'get',
    path: '/readyz',
    summary: 'Readiness',
    response: ReadyResponse,
    unversioned: true,
    public: true,
  },
  me: {
    method: 'get',
    path: '/me',
    summary: 'Current user, memberships and permissions',
    response: MeResponse,
  },
  orgGet: {
    method: 'get',
    path: '/organisations/{id}',
    summary: 'Get the organisation',
    response: OrganisationDto,
  },
  orgPatch: {
    method: 'patch',
    path: '/organisations/{id}',
    summary: 'Update the organisation (If-Match)',
    response: OrganisationDto,
  },
  locationsList: {
    method: 'get',
    path: '/organisations/{id}/locations',
    summary: 'List locations in scope',
    response: list(LocationDto),
  },
  locationsCreate: {
    method: 'post',
    path: '/organisations/{id}/locations',
    summary: 'Create a location',
    response: LocationDto,
  },
  locationsPatch: {
    method: 'patch',
    path: '/organisations/{id}/locations/{locationId}',
    summary: 'Update or archive a location (If-Match)',
    response: LocationDto,
  },
  servicesList: {
    method: 'get',
    path: '/organisations/{id}/services',
    summary: 'List service types',
    response: list(ServiceDto),
  },
  servicesCreate: {
    method: 'post',
    path: '/organisations/{id}/services',
    summary: 'Create a service type',
    response: ServiceDto,
  },
  servicesPatch: {
    method: 'patch',
    path: '/organisations/{id}/services/{serviceId}',
    summary: 'Update a service type (If-Match)',
    response: ServiceDto,
  },
  activitiesList: {
    method: 'get',
    path: '/organisations/{id}/registered-activities',
    summary: 'List registered activities',
    response: list(ActivityDto),
  },
  activitiesCreate: {
    method: 'post',
    path: '/organisations/{id}/registered-activities',
    summary: 'Create a registered activity',
    response: ActivityDto,
  },
  activitiesPatch: {
    method: 'patch',
    path: '/organisations/{id}/registered-activities/{activityId}',
    summary: 'Update a registered activity (If-Match)',
    response: ActivityDto,
  },
  adminUsers: {
    method: 'get',
    path: '/admin/users',
    summary: 'List users with access to the organisation',
    response: list(AdminUserDto),
  },
  adminInvite: {
    method: 'post',
    path: '/admin/users',
    summary: 'Invite a user with a role',
    response: zz.object({ id: uuid }),
  },
  adminAddMembership: {
    method: 'post',
    path: '/admin/users/{id}/memberships',
    summary: 'Add a role/location membership',
    response: zz.object({ membershipId: uuid }),
  },
  adminRevoke: {
    method: 'post',
    path: '/admin/users/{id}/revoke',
    summary: 'Revoke access immediately',
    response: zz.object({ revokedMemberships: zz.number(), revokedDevices: zz.number() }),
  },
  adminPermissions: {
    method: 'get',
    path: '/admin/permissions',
    summary: 'Permission catalogue',
    response: list(PermissionDto),
  },
  adminRoles: {
    method: 'get',
    path: '/admin/roles',
    summary: 'List system and custom roles',
    response: list(RoleDto),
  },
  adminRoleCreate: {
    method: 'post',
    path: '/admin/roles',
    summary: 'Create a custom role',
    response: RoleDto,
  },
  adminRolePatch: {
    method: 'patch',
    path: '/admin/roles/{id}',
    summary: 'Update a custom role (If-Match)',
    response: RoleDto,
  },
  adminSettings: {
    method: 'get',
    path: '/admin/settings',
    summary: 'Organisation settings',
    response: SettingsResponse,
  },
  adminSettingsPatch: {
    method: 'patch',
    path: '/admin/settings',
    summary: 'Update settings (If-Match)',
    response: SettingsResponse,
  },
  supportGrants: {
    method: 'get',
    path: '/admin/support-access-grants',
    summary: 'List break-glass grants',
    response: list(SupportGrantDto),
  },
  supportGrantCreate: {
    method: 'post',
    path: '/admin/support-access-grants',
    summary: 'Approve time-limited support access',
    response: SupportGrantDto,
  },
  templatesList: {
    method: 'get',
    path: '/requirements/templates',
    summary: 'Requirement templates (organisation and library)',
    response: list(TemplateDto),
  },
  templateCreate: {
    method: 'post',
    path: '/requirements/templates',
    summary: 'Create a template with its first draft version',
    response: TemplateDto,
  },
  templateAdopt: {
    method: 'post',
    path: '/requirements/templates/{id}/adopt',
    summary: 'Copy a library template into the organisation as a draft',
    response: TemplateDto,
  },
  templateVersionCreate: {
    method: 'post',
    path: '/requirements/templates/{id}/versions',
    summary: 'Create a new draft version',
    response: TemplateVersionDto,
  },
  templateVersionUpdate: {
    method: 'patch',
    path: '/requirements/templates/{id}/versions/{versionId}',
    summary: 'Edit a draft version',
    response: TemplateVersionDto,
  },
  templateVersionPublish: {
    method: 'post',
    path: '/requirements/templates/{id}/versions/{versionId}/publish',
    summary: 'Publish a draft (approver must differ from author)',
    response: TemplateVersionDto,
  },
  instancesList: {
    method: 'get',
    path: '/requirements/instances',
    summary: 'Requirement instances with status and reason',
    response: InstancePage,
  },
  instanceCreate: {
    method: 'post',
    path: '/requirements/instances',
    summary: 'Create a requirement instance for a subject',
    response: InstanceDto,
  },
  instanceGet: {
    method: 'get',
    path: '/requirements/instances/{id}',
    summary: 'Instance with decision and due-date history',
    response: InstanceDetailDto,
  },
  instancePatch: {
    method: 'patch',
    path: '/requirements/instances/{id}',
    summary: 'Set owner, deputy or location (If-Match)',
    response: InstanceDto,
  },
  instanceApplicability: {
    method: 'post',
    path: '/requirements/instances/{id}/applicability',
    summary: 'Record a not-applicable decision',
    response: InstanceDto,
  },
  instanceDueDateChange: {
    method: 'post',
    path: '/requirements/instances/{id}/due-date-change',
    summary: 'Change a deadline with reason and approver',
    response: InstanceDto,
  },
  instanceEvidence: {
    method: 'get',
    path: '/requirements/instances/{id}/evidence',
    summary: 'Evidence linked to an instance',
    response: list(EvidenceVersionDto),
  },
  evidenceUpload: {
    method: 'post',
    path: '/evidence/uploads',
    summary: 'Request an upload URL (quarantine)',
    response: UploadResponse,
  },
  evidenceBlobPut: {
    method: 'put',
    path: '/evidence/blob/{token}',
    summary: 'Upload bytes with a signed URL',
    response: zz.object({ received: zz.number().int() }),
    public: true,
  },
  evidenceComplete: {
    method: 'post',
    path: '/evidence/{versionId}/complete',
    summary: 'Finish an upload: checksum and scan',
    response: EvidenceVersionDto,
  },
  evidenceVerify: {
    method: 'post',
    path: '/evidence/{versionId}/verify',
    summary: 'Accept or reject evidence',
    response: EvidenceVersionDto,
  },
  evidenceLinks: {
    method: 'post',
    path: '/evidence/{itemId}/links',
    summary: 'Link evidence to requirement instances',
    response: LinkResponse,
  },
  evidenceDownload: {
    method: 'get',
    path: '/evidence/{versionId}/download',
    summary: 'Short-lived download URL (audited)',
    response: DownloadResponse,
  },
  evidenceBlobGet: {
    method: 'get',
    path: '/evidence/blob/{token}',
    summary: 'Download bytes with a signed URL',
    response: zz.unknown(),
    public: true,
  },
  alertsList: {
    method: 'get',
    path: '/alerts',
    summary: 'Alerts derived from requirement state',
    response: list(AlertDto),
  },
  alertAcknowledge: {
    method: 'post',
    path: '/alerts/{id}/acknowledge',
    summary: 'Acknowledge an alert (notifications only)',
    response: AlertDto,
  },
  alertSnooze: {
    method: 'post',
    path: '/alerts/{id}/snooze',
    summary: 'Snooze notifications (status unchanged)',
    response: AlertDto,
  },
  auditList: {
    method: 'get',
    path: '/audit-log',
    summary: 'Audit log (admin.audit.view)',
    response: AuditListResponse,
  },
  auditVerify: {
    method: 'post',
    path: '/audit-log/verify-chain',
    summary: 'Verify the audit hash chain (admin.audit.verify)',
    response: VerifyChainResponse,
  },
  // ---- M3 staff (HR-01..04) -------------------------------------------
  staffList: {
    method: 'get',
    path: '/staff',
    summary: 'Staff list (basic or clearance-only view by permission)',
    response: zz.union([
      StaffPage,
      zz.object({ data: zz.array(StaffClearanceDto), nextCursor: zz.string().nullable() }),
    ]),
  },
  staffCreate: {
    method: 'post',
    path: '/staff',
    summary: 'Create a staff record (CANDIDATE)',
    response: StaffDto,
  },
  staffMe: {
    method: 'get',
    path: '/staff/me',
    summary: 'Own staff profile, requirements and correction requests',
    response: MyStaffDto,
  },
  staffMyCorrection: {
    method: 'post',
    path: '/staff/me/corrections',
    summary: 'Request a correction to own record',
    response: CorrectionDto,
  },
  staffCorrections: {
    method: 'get',
    path: '/staff/corrections',
    summary: 'Open correction requests',
    response: list(CorrectionDto),
  },
  staffCorrectionDecide: {
    method: 'post',
    path: '/staff/corrections/{id}/decide',
    summary: 'Apply or reject a correction request',
    response: CorrectionDto,
  },
  roleRequirements: {
    method: 'get',
    path: '/staff/role-requirements',
    summary: 'Requirement templates required per staff role',
    response: list(RoleRequirementDto),
  },
  roleRequirementAdd: {
    method: 'post',
    path: '/staff/role-requirements',
    summary: 'Require a template for a role (recalculates staff, HR-03)',
    response: RoleRequirementDto,
  },
  roleRequirementRemove: {
    method: 'delete',
    path: '/staff/role-requirements/{id}',
    summary: 'Stop requiring a template for a role',
    response: zz.object({ removed: zz.literal(true) }),
  },
  trainingMatrix: {
    method: 'get',
    path: '/staff/training-matrix',
    summary: 'Required items by staff and role with status',
    response: MatrixDto,
  },
  staffGet: {
    method: 'get',
    path: '/staff/{id}',
    summary: 'Staff profile (or clearance-only view)',
    response: zz.union([StaffDetailDto, StaffClearanceDto]),
  },
  staffPatch: {
    method: 'patch',
    path: '/staff/{id}',
    summary: 'Edit basic staff details (If-Match)',
    response: StaffDto,
  },
  staffTransition: {
    method: 'post',
    path: '/staff/{id}/transition',
    summary: 'Lifecycle transition with reason',
    response: StaffDto,
  },
  staffReadiness: {
    method: 'get',
    path: '/staff/{id}/readiness',
    summary: 'Readiness for a role across a time window',
    response: ReadinessDto,
  },
  staffRoleApprove: {
    method: 'post',
    path: '/staff/{id}/role-approvals',
    summary: 'Approve the staff member for a role',
    response: RoleApprovalDto,
  },
  staffRoleRevoke: {
    method: 'post',
    path: '/staff/{id}/role-approvals/{approvalId}/revoke',
    summary: 'Revoke a role approval',
    response: RoleApprovalDto,
  },
  staffRestrict: {
    method: 'post',
    path: '/staff/{id}/restrictions',
    summary: 'Apply a restriction (immediate)',
    response: RestrictionDto,
  },
  staffRestrictionLift: {
    method: 'post',
    path: '/staff/{id}/restrictions/{restrictionId}/lift',
    summary: 'Lift a restriction',
    response: RestrictionDto,
  },
  staffRecords: {
    method: 'get',
    path: '/staff/{id}/{kind}',
    summary: 'Records of one kind (references, dbs, right-to-work, licences, ...)',
    response: list(StaffRecordDto),
  },
  staffRecordAdd: {
    method: 'post',
    path: '/staff/{id}/{kind}',
    summary: 'Add a record (or a correction superseding one)',
    response: StaffRecordDto,
  },
};

export function buildOpenApi(version = '0.0.0') {
  const paths: Record<string, Record<string, unknown>> = {};
  for (const r of Object.values(routes)) {
    const full = r.unversioned ? r.path : `/api/v1${r.path}`;
    paths[full] ??= {};
    paths[full][r.method] = {
      summary: r.summary,
      security: r.public ? [] : [{ bearer: [] }],
      parameters: r.public
        ? []
        : [
            {
              name: 'X-Org-Id',
              in: 'header',
              required: false,
              schema: { type: 'string', format: 'uuid' },
            },
          ],
      responses: {
        '200': {
          description: 'OK',
          content: { 'application/json': { schema: z.toJSONSchema(r.response) } },
        },
        default: {
          description: 'Error (RFC 9457 problem+json)',
          content: { 'application/problem+json': { schema: z.toJSONSchema(Problem) } },
        },
      },
    };
  }
  return {
    openapi: '3.1.0',
    info: { title: 'Healthcare Hub API', version },
    components: {
      securitySchemes: { bearer: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
    },
    paths,
  };
}
