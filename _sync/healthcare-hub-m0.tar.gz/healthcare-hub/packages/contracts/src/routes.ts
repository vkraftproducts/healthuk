import { z } from 'zod';
import { AuditListResponse, VerifyChainResponse } from './audit.js';
import { HealthResponse, ReadyResponse } from './health.js';
import { MeResponse } from './me.js';
import { Problem } from './problem.js';

export interface RouteDef {
  method: 'get' | 'post' | 'patch' | 'delete';
  path: string; // relative to /api/v1 unless `unversioned`
  summary: string;
  response: z.ZodType;
  unversioned?: boolean;
  public?: boolean;
}

/** Registry used to generate OpenAPI. Add every endpoint here with its zod schemas. */
export const routes: Record<string, RouteDef> = {
  healthz: {
    method: 'get',
    path: '/healthz',
    summary: 'Liveness',
    response: HealthResponse,
    unversioned: true,
    public: true,
  },
  readyz: {
    method: 'get',
    path: '/readyz',
    summary: 'Readiness',
    response: ReadyResponse,
    unversioned: true,
    public: true,
  },
  me: {
    method: 'get',
    path: '/me',
    summary: 'Current user, memberships and permissions',
    response: MeResponse,
  },
  auditList: {
    method: 'get',
    path: '/audit-log',
    summary: 'Audit log (admin.audit.view)',
    response: AuditListResponse,
  },
  auditVerify: {
    method: 'post',
    path: '/audit-log/verify-chain',
    summary: 'Verify the audit hash chain (admin.audit.verify)',
    response: VerifyChainResponse,
  },
};

export function buildOpenApi(version = '0.0.0') {
  const paths: Record<string, Record<string, unknown>> = {};
  for (const r of Object.values(routes)) {
    const full = r.unversioned ? r.path : `/api/v1${r.path}`;
    paths[full] ??= {};
    paths[full][r.method] = {
      summary: r.summary,
      security: r.public ? [] : [{ bearer: [] }],
      parameters: r.public
        ? []
        : [
            {
              name: 'X-Org-Id',
              in: 'header',
              required: false,
              schema: { type: 'string', format: 'uuid' },
            },
          ],
      responses: {
        '200': {
          description: 'OK',
          content: { 'application/json': { schema: z.toJSONSchema(r.response) } },
        },
        default: {
          description: 'Error (RFC 9457 problem+json)',
          content: { 'application/problem+json': { schema: z.toJSONSchema(Problem) } },
        },
      },
    };
  }
  return {
    openapi: '3.1.0',
    info: { title: 'Healthcare Hub API', version },
    components: {
      securitySchemes: { bearer: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
    },
    paths,
  };
}
