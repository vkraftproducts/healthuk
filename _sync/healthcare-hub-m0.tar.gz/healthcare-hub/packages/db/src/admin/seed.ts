// Synthetic data only (CLAUDE.md #10). Matches the wireframes: "Example organisation / Watford"
// plus a second organisation used by isolation tests. Fixed IDs make the seed idempotent.
// Runs as the migrator role; sets the org context itself because RLS is FORCEd.
import pg from 'pg';

const IDS = {
  orgExample: '01900000-0000-7000-8000-000000000001',
  orgOther: '01900000-0000-7000-8000-000000000002',
  locWatford: '01900000-0000-7000-8000-000000000011',
  locOther: '01900000-0000-7000-8000-000000000012',
  userManager: '01900000-0000-7000-8000-000000000101',
  userOtherManager: '01900000-0000-7000-8000-000000000102',
  roleManager: '01900000-0000-7000-8000-000000000201',
  roleOtherManager: '01900000-0000-7000-8000-000000000202',
};

export async function seed(adminUrl: string): Promise<void> {
  const c = new pg.Client({ connectionString: adminUrl });
  await c.connect();
  try {
    await c.query('BEGIN');
    const ctx = (org: string) => c.query(`SELECT set_config('app.org_id', $1, true)`, [org]);

    // Permission catalogue (global, not tenant data). The full RBAC matrix arrives in M1.
    for (const [key, description] of [
      ['dashboard.view', 'View the dashboard'],
      ['admin.audit.view', 'View the audit log'],
      ['admin.audit.verify', 'Verify the audit hash chain'],
    ] as const) {
      await c.query(
        `INSERT INTO permission (key, description) VALUES ($1, $2) ON CONFLICT (key) DO NOTHING`,
        [key, description],
      );
    }

    await ctx(IDS.orgExample);
    await c.query(
      `INSERT INTO organisation (id, name, sector_packs) VALUES ($1, 'Example organisation', '{ambulance}')
       ON CONFLICT (id) DO NOTHING`,
      [IDS.orgExample],
    );
    await c.query(
      `INSERT INTO location (id, organisation_id, name, registered) VALUES ($1, $2, 'Watford', true)
       ON CONFLICT (id) DO NOTHING`,
      [IDS.locWatford, IDS.orgExample],
    );
    await c.query(
      `INSERT INTO app_user (id, idp_subject, email, display_name, status)
       VALUES ($1, 'dev|manager', 'manager@example.test', 'Dev Manager', 'ACTIVE')
       ON CONFLICT (id) DO NOTHING`,
      [IDS.userManager],
    );
    await c.query(
      `INSERT INTO role (id, organisation_id, key, name) VALUES ($1, $2, 'REGISTERED_MANAGER', 'Registered manager')
       ON CONFLICT (id) DO NOTHING`,
      [IDS.roleManager, IDS.orgExample],
    );
    await c.query(
      `INSERT INTO role_permission (role_id, permission_key)
       SELECT $1, key FROM permission ON CONFLICT DO NOTHING`,
      [IDS.roleManager],
    );
    await c.query(
      `INSERT INTO membership (organisation_id, user_id, role_id)
       SELECT $1, $2, $3 WHERE NOT EXISTS
         (SELECT 1 FROM membership WHERE organisation_id = $1 AND user_id = $2)`,
      [IDS.orgExample, IDS.userManager, IDS.roleManager],
    );

    await ctx(IDS.orgOther);
    await c.query(
      `INSERT INTO organisation (id, name) VALUES ($1, 'Other organisation') ON CONFLICT (id) DO NOTHING`,
      [IDS.orgOther],
    );
    await c.query(
      `INSERT INTO location (id, organisation_id, name) VALUES ($1, $2, 'Elsewhere')
       ON CONFLICT (id) DO NOTHING`,
      [IDS.locOther, IDS.orgOther],
    );
    await c.query(
      `INSERT INTO app_user (id, idp_subject, email, display_name, status)
       VALUES ($1, 'dev|other-manager', 'other.manager@example.test', 'Other Manager', 'ACTIVE')
       ON CONFLICT (id) DO NOTHING`,
      [IDS.userOtherManager],
    );
    await c.query(
      `INSERT INTO role (id, organisation_id, key, name) VALUES ($1, $2, 'REGISTERED_MANAGER', 'Registered manager')
       ON CONFLICT (id) DO NOTHING`,
      [IDS.roleOtherManager, IDS.orgOther],
    );
    await c.query(
      `INSERT INTO membership (organisation_id, user_id, role_id)
       SELECT $1, $2, $3 WHERE NOT EXISTS
         (SELECT 1 FROM membership WHERE organisation_id = $1 AND user_id = $2)`,
      [IDS.orgOther, IDS.userOtherManager, IDS.roleOtherManager],
    );
    await c.query('COMMIT');
  } catch (e) {
    await c.query('ROLLBACK');
    throw e;
  } finally {
    await c.end();
  }
}

export const SEED_IDS = IDS;
