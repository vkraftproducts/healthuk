import { MeResponse, Problem } from '@hub/contracts';
import type { AuthClient } from './auth.js';

export class ApiError extends Error {
  constructor(
    public readonly status: number,
    public readonly code: string,
  ) {
    super(`API ${status} ${code}`);
  }
}

export interface ApiClient {
  me(orgId: string | null): Promise<MeResponse>;
  readyz(): Promise<{ status: string }>;
}

export function createApiClient(auth: AuthClient, baseUrl = ''): ApiClient {
  async function request(
    path: string,
    orgId: string | null,
    authenticated = true,
  ): Promise<unknown> {
    const headers: Record<string, string> = {};
    if (authenticated) headers.authorization = `Bearer ${await auth.getToken()}`;
    if (orgId) headers['x-org-id'] = orgId;
    const res = await fetch(`${baseUrl}${path}`, { headers });
    if (!res.ok) {
      const parsed = Problem.safeParse(await res.json().catch(() => null));
      throw new ApiError(res.status, parsed.success ? parsed.data.code : 'INTERNAL');
    }
    return res.json();
  }
  return {
    me: async (orgId) => MeResponse.parse(await request('/api/v1/me', orgId)),
    readyz: async () => (await request('/readyz', null, false)) as { status: string },
  };
}
