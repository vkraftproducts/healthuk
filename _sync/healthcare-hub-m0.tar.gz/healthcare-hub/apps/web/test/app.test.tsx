import { createMemoryHistory } from '@tanstack/react-router';
import { render, screen, waitFor, within } from '@testing-library/react';
import userEvent from '@testing-library/user-event';
import type { MeResponse } from '@hub/contracts';
import { describe, expect, it, vi } from 'vitest';
import type { ApiClient } from '../src/api.js';
import { App } from '../src/App.js';
import { NAV_ITEMS } from '../src/nav.js';

const ORG_A = '01900000-0000-7000-8000-000000000001';
const ORG_B = '01900000-0000-7000-8000-000000000002';

const me = (orgId: string | null, permissions: string[]): MeResponse => ({
  user: {
    id: '01900000-0000-7000-8000-000000000101',
    email: 'm@example.test',
    displayName: 'Dev Manager',
  },
  memberships: [
    {
      organisationId: ORG_A,
      organisationName: 'Example organisation',
      locationId: null,
      roleKey: 'REGISTERED_MANAGER',
      roleName: 'Registered manager',
    },
    {
      organisationId: ORG_B,
      organisationName: 'Second organisation',
      locationId: null,
      roleKey: 'HR_LEAD',
      roleName: 'HR lead',
    },
  ],
  permissions,
  activeOrganisationId: orgId,
  mfa: { required: true, satisfied: true },
});

function renderApp(api: ApiClient) {
  return render(<App api={api} history={createMemoryHistory({ initialEntries: ['/'] })} />);
}

describe('web shell', () => {
  it('shows every module in the left navigation', async () => {
    renderApp({
      me: async (o) => me(o, ['dashboard.view']),
      readyz: async () => ({ status: 'ready' }),
    });
    const nav = await screen.findByRole('navigation', { name: 'Primary' });
    for (const item of NAV_ITEMS)
      expect(within(nav).getByRole('link', { name: item.label })).toBeInTheDocument();
    expect(within(nav).getByRole('link', { name: 'Dashboard' })).toHaveAttribute(
      'aria-current',
      'page',
    );
  });

  it("lists only the user's organisations and re-queries with the selected one", async () => {
    const meFn = vi.fn(async (o: string | null) => me(o, ['dashboard.view']));
    renderApp({ me: meFn, readyz: async () => ({ status: 'ready' }) });
    const select = await screen.findByLabelText('Organisation');
    expect(
      within(select)
        .getAllByRole('option')
        .map((o) => o.textContent),
    ).toEqual(['Example organisation', 'Second organisation']);
    await userEvent.selectOptions(select, ORG_B);
    await waitFor(() => expect(meFn).toHaveBeenCalledWith(ORG_B));
  });

  it('shows KPI tiles as "not connected" instead of fake zeros, with the internal-measure notice', async () => {
    renderApp({
      me: async (o) => me(o, ['dashboard.view']),
      readyz: async () => ({ status: 'ready' }),
    });
    expect(await screen.findByText('Overdue tasks')).toBeInTheDocument();
    expect(screen.getAllByText(/not connected yet/).length).toBeGreaterThanOrEqual(4);
    expect(screen.getByText(/not CQC ratings/)).toBeInTheDocument();
  });

  it('hides dashboard content without the permission (server still enforces)', async () => {
    renderApp({ me: async (o) => me(o, []), readyz: async () => ({ status: 'ready' }) });
    expect(await screen.findByRole('alert')).toHaveTextContent('do not have permission');
    expect(screen.queryByText('Overdue tasks')).toBeNull();
  });

  it('shows an explicit source-unavailable state, with text and not colour alone', async () => {
    renderApp({
      me: async (o) => me(o, ['dashboard.view']),
      readyz: async () => ({ status: 'degraded' }),
    });
    expect(await screen.findByText('Red – source unavailable')).toBeInTheDocument();
  });

  it('shows an error (no stale data) when the account cannot be loaded', async () => {
    renderApp({
      me: async () => {
        throw new Error('boom');
      },
      readyz: async () => ({ status: 'ready' }),
    });
    expect(await screen.findByRole('alert')).toHaveTextContent('Source unavailable');
  });
});
