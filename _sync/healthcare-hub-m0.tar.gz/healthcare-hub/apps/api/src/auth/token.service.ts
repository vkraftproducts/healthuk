import { Inject, Injectable } from '@nestjs/common';
import { jwtVerify, type JWTVerifyGetKey } from 'jose';
import { CONFIG, type AppConfig } from '../config.js';
import { HubError } from '../common/problem.filter.js';

export const KEY_RESOLVER = Symbol('KEY_RESOLVER');

export interface VerifiedToken {
  sub: string;
  /** Authentication methods references; MFA satisfied when it includes `mfa`. */
  amr: readonly string[];
}

@Injectable()
export class TokenService {
  constructor(
    @Inject(CONFIG) private readonly config: AppConfig,
    @Inject(KEY_RESOLVER) private readonly keys: JWTVerifyGetKey,
  ) {}

  /** Validates signature, issuer, audience and expiry. Any failure is a generic 401. */
  async verify(token: string): Promise<VerifiedToken> {
    try {
      const { payload } = await jwtVerify(token, this.keys, {
        issuer: this.config.OIDC_ISSUER,
        audience: this.config.OIDC_AUDIENCE,
        algorithms: ['RS256', 'ES256', 'PS256'],
        clockTolerance: 5,
        requiredClaims: ['sub', 'exp'],
      });
      const amr = Array.isArray(payload.amr)
        ? payload.amr.filter((v): v is string => typeof v === 'string')
        : [];
      return { sub: String(payload.sub), amr };
    } catch {
      throw new HubError('UNAUTHENTICATED', 401);
    }
  }
}
