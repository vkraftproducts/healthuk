import { createHmac } from 'node:crypto';
import { Inject, Injectable, type CanActivate, type ExecutionContext } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import { DB } from '../db.provider.js';
import type { Db, ResolvedUser } from '@hub/db';
import { CONFIG, type AppConfig } from '../config.js';
import { PUBLIC_KEY } from '../common/decorators.js';
import type { HubRequest } from '../common/context.js';
import { HubError, notFound } from '../common/problem.filter.js';
import { mfaRequiredFor } from './mfa.js';
import { TokenService } from './token.service.js';

const USER_CACHE_TTL_MS = 30_000; // revocation latency bound (SECURITY_COMPLIANCE §1)
const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

/**
 * Authentication + request context (runs before PermissionGuard):
 *  1. Verify the bearer token (issuer, audience, expiry, signature).
 *  2. Map the IdP subject to a user; only ACTIVE users pass (leavers/suspended => 401).
 *  3. If X-Org-Id is sent, it must match one of the user's current memberships (else 404).
 *  4. Resolve roles, permissions and location scope from the database - never from the token.
 */
@Injectable()
export class HubGuard implements CanActivate {
  private readonly users = new Map<string, { user: ResolvedUser | null; at: number }>();

  constructor(
    @Inject(Reflector) private readonly reflector: Reflector,
    @Inject(TokenService) private readonly tokens: TokenService,
    @Inject(DB) private readonly db: Db,
    @Inject(CONFIG) private readonly config: AppConfig,
  ) {}

  async canActivate(ctx: ExecutionContext): Promise<boolean> {
    if (this.reflector.getAllAndOverride<boolean>(PUBLIC_KEY, [ctx.getHandler(), ctx.getClass()])) {
      return true;
    }
    const req = ctx.switchToHttp().getRequest<HubRequest>();
    const header = req.headers.authorization;
    const match = typeof header === 'string' ? /^Bearer (\S+)$/.exec(header) : null;
    if (!match?.[1]) throw new HubError('UNAUTHENTICATED', 401);

    const token = await this.tokens.verify(match[1]);
    const user = await this.lookupUser(token.sub);
    if (!user) throw new HubError('UNAUTHENTICATED', 401);
    if (user.status !== 'ACTIVE') throw new HubError('USER_INACTIVE', 401);

    const ipHash = createHmac('sha256', this.config.IP_HASH_SECRET)
      .update(req.ip ?? '')
      .digest('hex');
    const mfaSatisfied = token.amr.includes('mfa');
    const orgHeader = req.headers['x-org-id'];
    const locHeader = req.headers['x-location-id'];

    const now = new Date();
    const memberships = await this.db.withIdentity(user.id, (tx) =>
      tx.membership.findMany({
        where: {
          userId: user.id,
          validFrom: { lte: now },
          OR: [{ validTo: null }, { validTo: { gt: now } }],
        },
        include: { role: { include: { rolePermissions: true } } },
      }),
    );

    let orgId: string | null = null;
    let roleKeys: string[] = [];
    let permissions = new Set<string>();
    let locationIds: string[] | null = null;

    if (typeof orgHeader === 'string' && orgHeader !== '') {
      if (!UUID.test(orgHeader)) throw notFound();
      const inOrg = memberships.filter((m) => m.organisationId === orgHeader);
      if (inOrg.length === 0) throw notFound(); // never reveal that the organisation exists
      orgId = orgHeader;
      roleKeys = [...new Set(inOrg.map((m) => m.role.key))];
      permissions = new Set(
        inOrg.flatMap((m) => m.role.rolePermissions.map((rp) => rp.permissionKey)),
      );
      locationIds = inOrg.some((m) => m.locationId === null)
        ? null
        : [...new Set(inOrg.map((m) => m.locationId as string))];
      if (typeof locHeader === 'string' && locHeader !== '') {
        if (!UUID.test(locHeader) || (locationIds !== null && !locationIds.includes(locHeader))) {
          throw notFound();
        }
        locationIds = [locHeader];
      }
    }

    req.hub = {
      user: { id: user.id, email: user.email, displayName: user.displayName },
      orgId,
      roleKeys,
      permissions,
      locationIds,
      mfaSatisfied,
      mfaRequired: mfaRequiredFor(roleKeys),
      ipHash,
    };
    return true;
  }

  private async lookupUser(sub: string): Promise<ResolvedUser | null> {
    const hit = this.users.get(sub);
    const now = Date.now();
    if (hit && now - hit.at < USER_CACHE_TTL_MS) return hit.user;
    const user = await this.db.resolveUser(sub);
    this.users.set(sub, { user, at: now });
    if (this.users.size > 5_000) this.users.clear();
    return user;
  }

  /** Immediate revocation hook (e.g. leaver flow in M1). */
  evict(sub: string): void {
    this.users.delete(sub);
  }
}
