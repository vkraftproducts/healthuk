import { RequestMethod } from '@nestjs/common';
import { Reflector } from '@nestjs/core';
import type { NestFastifyApplication } from '@nestjs/platform-fastify';
import { afterAll, beforeAll, describe, expect, inject, it } from 'vitest';
import { CONTROLLERS } from '../src/app.module.js';
import { AUTH_ONLY_KEY, PERMISSION_KEY, PUBLIC_KEY } from '../src/common/decorators.js';
import { SEED_IDS, makeApp, sign } from './harness.js';

/**
 * TEST_PLAN §4: generated isolation suite. For EVERY non-public route (discovered from controller
 * metadata, so new endpoints are covered automatically) assert:
 *   - no token                         -> 401
 *   - member of ANOTHER organisation   -> 404 (never reveals the record or organisation exists)
 *   - member without the permission    -> 403
 */
const urls = inject('urls');
let app: NestFastifyApplication;
let closeAll: () => Promise<void>;

interface Route {
  name: string;
  method: 'GET' | 'POST' | 'PATCH' | 'PUT' | 'DELETE';
  url: string;
  needsPermission: boolean;
}

const METHODS: Record<number, Route['method']> = {
  [RequestMethod.GET]: 'GET',
  [RequestMethod.POST]: 'POST',
  [RequestMethod.PATCH]: 'PATCH',
  [RequestMethod.PUT]: 'PUT',
  [RequestMethod.DELETE]: 'DELETE',
};
const SAMPLE_UUID = '01900000-0000-7000-8000-0000000000ff';

function discover(): Route[] {
  const reflector = new Reflector();
  const out: Route[] = [];
  for (const C of CONTROLLERS) {
    const base = String(Reflect.getMetadata('path', C) ?? '').replace(/^\/|\/$/g, '');
    for (const name of Object.getOwnPropertyNames(C.prototype)) {
      const fn = (C.prototype as unknown as Record<string, unknown>)[name];
      if (typeof fn !== 'function') continue;
      const sub = Reflect.getMetadata('path', fn) as string | undefined;
      const m = Reflect.getMetadata('method', fn) as number | undefined;
      if (sub === undefined || m === undefined) continue;
      if (reflector.get(PUBLIC_KEY, fn)) continue;
      const path = [base, sub.replace(/^\/|\/$/g, '')].filter(Boolean).join('/').replace(/:[A-Za-z]+/g, SAMPLE_UUID);
      out.push({
        name: `${C.name}.${name}`,
        method: METHODS[m] ?? 'GET',
        url: `/api/v1/${path}`,
        needsPermission: !reflector.get(AUTH_ONLY_KEY, fn) && ((reflector.get(PERMISSION_KEY, fn) as string[] | undefined)?.length ?? 0) > 0,
      });
    }
  }
  return out;
}

const routes = discover();

beforeAll(async () => {
  const made = await makeApp(urls);
  app = made.app;
  closeAll = async () => {
    await app.close();
    await made.db.close();
  };
});
afterAll(async () => closeAll());

const call = async (r: Route, headers: Record<string, string>) =>
  (await app.inject({ method: r.method, url: r.url, headers })).statusCode;

describe('generated isolation suite', () => {
  it('discovers the protected routes', () => {
    expect(routes.length).toBeGreaterThanOrEqual(3);
  });

  describe.each(routes)('$method $url ($name)', (r) => {
    it('rejects an unauthenticated call (401)', async () => {
      expect(await call(r, {})).toBe(401);
    });

    it('answers 404 to a member of another organisation using this organisation id', async () => {
      const token = await sign({ sub: 'dev|other-manager' });
      const status = await call(r, { authorization: `Bearer ${token}`, 'x-org-id': SEED_IDS.orgExample });
      expect(status).toBe(404);
    });

    it.runIf(r.needsPermission)('answers 403 to a member without the permission', async () => {
      const token = await sign({ sub: 'dev|other-manager' });
      const status = await call(r, { authorization: `Bearer ${token}`, 'x-org-id': SEED_IDS.orgOther });
      expect(status).toBe(403);
    });
  });
});
