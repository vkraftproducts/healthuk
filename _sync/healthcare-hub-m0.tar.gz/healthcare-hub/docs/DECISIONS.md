# Decisions, assumptions and open questions

## ADR index (`docs/adr/`)

| ADR  | Decision                                                                                   |
| ---- | ------------------------------------------------------------------------------------------ |
| 0001 | Modular monolith on Azure Container Apps (cost, simplicity)                                |
| 0002 | Postgres RLS + app-level scoping for tenant isolation                                      |
| 0003 | Entra External ID for identity; authorisation in-app                                       |
| 0004 | pg-boss instead of Service Bus/Functions for background jobs                               |
| 0005 | Expo React Native for the crew app (not PWA) — offline + device storage + push reliability |

## Baseline assumptions (from brief; confirm in discovery)

- A1 England only (CQC). Other UK nations need separate regulator packs later.
- A2 Pilot: 100 staff, 50 vehicles, 10 locations, 500 jobs/day.
- A3 Crew use company-managed devices (affects MDM and distribution). _Confirm._
- A4 No integration with NHS systems or clinical decision support in initial scope.
- A5 FleetX/payroll/telematics: CSV import/export first; APIs only after licences confirmed.
- A6 Default warning windows 90/60/30/14/7 days are product defaults.
- A7 Retention periods are placeholders until the organisation approves its schedule.
- A8 Requirement library content (ambulance pack) ships **inactive** until governance approval.
- A9 Single region (UK South) with UK West backups meets NFR-01 for pilot; zone-redundant HA later.

## Open questions for the product owner

1. Pilot organisations, locations and registered activities?
2. Company devices or BYOD? MDM in place (Intune)?
3. Who are deputies for escalation per role?
4. Approved retention schedule per record category?
5. Integration priority order (FleetX, payroll, training provider, telematics, calendar)?
6. Are dental / care-home packs in year 1?
7. SMS notifications needed (cost) or email + push enough?
8. Custom domain and branding?

## Agent assumptions (append as you go: date, context, decision, reason)

### 2026-10-30 · M0 · Build environment and library choices
- **Prisma 7 (not 5) with the `pg` driver adapter.** Prisma 5 needs engine binaries from
  `binaries.prisma.sh`, which was blocked in the build sandbox. Prisma 7 is engine-free for the
  client. `prisma migrate` is also not used: schema changes are **forward-only SQL files** in
  `packages/db/sql/migrations` (RLS, triggers and exclusion constraints need raw SQL anyway),
  applied by a checksummed runner. `prisma/schema.prisma` is the typed-client mirror and must be
  updated by hand when a migration changes a table. Supersedes "Prisma 5" in ARCHITECTURE.md.
- **Newer majors than the architecture doc names** (resolved at install, then pinned): NestJS 12,
  Zod 4, Vitest 5, Vite, Tailwind 3.4 (kept on 3), TypeScript 5.9 (TypeScript 7 deliberately not used
  until the ecosystem catches up). OpenAPI is generated from Zod 4's native JSON Schema output instead
  of `nestjs-zod`.
- **No `emitDecoratorMetadata`.** Nest providers use explicit `@Inject(...)` so the same code works
  under tsc, tsx and Vitest.
- **Tests use a Postgres 16 service/instance, not Testcontainers**, because Docker was unavailable in
  the build sandbox. CI provides a `postgres:16` service; local runs use `docker compose up postgres`
  or `TEST_SUPERUSER_URL`. Testcontainers can be added later without changing the tests.
- **`app_user` is not a tenant table** (a person can belong to several organisations). It uses ENABLE
  but not FORCE RLS so the SECURITY DEFINER `auth_resolve_user()` can map a verified IdP subject to a
  user before any organisation context exists. Everything else with `organisation_id` is FORCE RLS
  (asserted by a test).
- **Audit chain is computed in the database** (BEFORE INSERT trigger, per-organisation advisory lock),
  so the application cannot forge or skip `seq`/`hash`. `audit_verify_chain()` recomputes it. A superuser
  who disables triggers can still alter rows, but the change is detected (tested); the daily WORM anchor
  (M2 worker) closes the remaining gap.
- **MFA** is read from the token `amr` claim containing `mfa`. Confirm Entra External ID emits this when
  the tenant is created, and record the tenant data location (SECURITY_COMPLIANCE §8).
- **Web tokens are held in memory only.** The BFF/httpOnly-cookie flow described in
  SECURITY_COMPLIANCE §1 is wired with Entra; until then development uses the mock OIDC server.
- **Permissions beyond three** (`dashboard.view`, `admin.audit.view`, `admin.audit.verify`) and the
  role matrix are seeded in M1.

