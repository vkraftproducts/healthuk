import { DataTable, StatusBadge, type StatusKind } from '@hub/ui';
import { useState } from 'react';
import { saveBlob, smallButton, useCan, useRun, words } from '../components.js';
import { useApp } from '../shell/AppContext.js';
import { useOne } from './settings/hooks.js';

type Row = Record<string, any>; // eslint-disable-line @typescript-eslint/no-explicit-any

/** Tiles are counted separately and never merged; each opens its exact drill-down (PRD §4.2, UAT-08). */
const TILES = [
  { key: 'overdue', label: 'Overdue tasks', kind: 'RED' as StatusKind },
  { key: 'dueSoon', label: 'Due in 30 days', kind: 'AMBER' as StatusKind },
  { key: 'blockedVehicles', label: 'Blocked vehicles', kind: 'RED' as StatusKind },
  { key: 'jobsToday', label: 'Jobs today', kind: 'GREY' as StatusKind },
] as const;
const MODULE_LABEL: Record<string, string> = {
  STAFF: 'Staff',
  FLEET: 'Fleet',
  COMPLIANCE: 'Compliance',
  PREMISES: 'Premises',
  EVENTS: 'Events',
};

export function Dashboard() {
  const { me, orgId, api } = useApp();
  const can = useCan();
  const canView = me.permissions.includes('dashboard.view');
  const [tile, setTile] = useState<string>('all');
  const [module, setModule] = useState<string>('');
  const q = module ? `module=${module}` : '';
  const summary = useOne<Row>(canView ? `/api/v1/dashboard/summary${q ? `?${q}` : ''}` : null);
  const rows = useOne<{ data: Row[] }>(
    canView ? `/api/v1/dashboard/actions?tile=${tile}${q ? `&${q}` : ''}` : null,
  );
  const { run, msg } = useRun();
  const s = summary.data;
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">Home dashboard</h1>
        <p className="text-slate-700">
          An action-led overview for the registered manager and operations team.
        </p>
      </div>
      {!orgId ? (
        <p role="status">Select an organisation to continue.</p>
      ) : !canView ? (
        <p role="alert">You do not have permission to view the dashboard for this organisation.</p>
      ) : summary.isError ? (
        <div role="alert" className="rounded border border-red-700 bg-red-50 p-3 text-red-900">
          <strong>Source unavailable.</strong> The dashboard could not be loaded. Figures are not
          shown rather than shown out of date.
        </div>
      ) : (
        <>
          <section
            aria-label="Key figures"
            className="grid grid-cols-2 gap-4 lg:grid-cols-4"
            aria-busy={summary.isLoading}
          >
            {TILES.map((t) => {
              const value = s ? (s.tiles[t.key] as number | null) : undefined;
              const connected = value !== null && value !== undefined;
              const selected = tile === t.key;
              return (
                <button
                  key={t.key}
                  type="button"
                  disabled={!connected}
                  aria-pressed={selected}
                  onClick={() => setTile(selected ? 'all' : t.key)}
                  className={`rounded border bg-white p-4 text-left ${selected ? 'border-slate-900 ring-2 ring-slate-900' : 'border-slate-300'}`}
                >
                  <div className="text-sm text-slate-700">{t.label}</div>
                  <div
                    className="mt-1 text-3xl font-bold"
                    aria-label={
                      connected ? `${t.label}: ${value}` : `${t.label}: not connected yet`
                    }
                  >
                    {summary.isLoading ? '…' : connected ? value : '—'}
                  </div>
                  <div className="mt-2">
                    {connected ? (
                      <StatusBadge
                        status={value === 0 ? 'GREEN' : t.kind}
                        reason={
                          value === 0 ? 'none' : selected ? 'showing below' : 'select to list'
                        }
                      />
                    ) : (
                      <StatusBadge status="GREY" reason="not connected yet" />
                    )}
                  </div>
                </button>
              );
            })}
          </section>

          <div className="grid gap-6 lg:grid-cols-3">
            <section
              aria-labelledby="actions-h"
              className="rounded border border-slate-300 bg-white p-4 lg:col-span-2"
            >
              <div className="mb-2 flex flex-wrap items-center justify-between gap-2">
                <h2 id="actions-h" className="text-lg font-semibold">
                  Action required
                  {tile !== 'all'
                    ? ` – ${TILES.find((t) => t.key === tile)?.label ?? words(tile)}`
                    : ''}
                </h2>
                <div className="flex gap-2">
                  {tile !== 'all' && (
                    <button className={smallButton} onClick={() => setTile('all')}>
                      View all
                    </button>
                  )}
                  {can('reports.export') && (
                    <button
                      className={smallButton}
                      onClick={() =>
                        void run(
                          async () =>
                            saveBlob(
                              await api.download!(
                                `/api/v1/dashboard/actions/export?tile=${tile}`,
                                orgId,
                              ),
                              'action-required.csv',
                            ),
                          'Export downloaded (logged).',
                        )
                      }
                    >
                      Export
                    </button>
                  )}
                </div>
              </div>
              {msg}
              <DataTable<Row>
                caption="Action required"
                rows={rows.data?.data ?? []}
                rowKey={(r) => r.key}
                loading={rows.isLoading}
                error={rows.isError ? 'Could not load the action list.' : null}
                emptyMessage="Nothing needs action."
                columns={[
                  {
                    key: 'item',
                    header: 'Item',
                    cell: (r) => `${MODULE_LABEL[r.module] ?? r.module}: ${r.item}`,
                  },
                  {
                    key: 'owner',
                    header: 'Owner',
                    cell: (r) => (r.ownerUserId ? 'Assigned' : 'Unassigned'),
                  },
                  { key: 'deadline', header: 'Deadline', cell: (r) => r.deadline ?? '—' },
                  {
                    key: 'state',
                    header: 'State',
                    cell: (r) => (
                      <StatusBadge status={r.status as StatusKind} reason={r.reasonText} />
                    ),
                  },
                ]}
              />
            </section>

            <div className="space-y-6">
              <section
                aria-labelledby="modules-h"
                className="rounded border border-slate-300 bg-white p-4"
              >
                <h2 id="modules-h" className="mb-2 text-lg font-semibold">
                  Module status
                </h2>
                <ul className="space-y-2">
                  {(s?.modules ?? []).map((m: Row) => (
                    <li key={m.module}>
                      <button
                        className="flex w-full items-center justify-between gap-2 text-left"
                        aria-pressed={module === m.module}
                        onClick={() => setModule(module === m.module ? '' : m.module)}
                      >
                        <span>
                          {MODULE_LABEL[m.module]} ({m.count} {m.label})
                        </span>
                        <StatusBadge status={m.status as StatusKind} />
                      </button>
                    </li>
                  ))}
                </ul>
                <p className="mt-2 text-sm text-slate-700">
                  Click a module to see the exact requirements.
                </p>
              </section>
              <section
                aria-labelledby="ops-h"
                className="rounded border border-slate-300 bg-white p-4"
              >
                <h2 id="ops-h" className="mb-2 text-lg font-semibold">
                  Today in operations
                </h2>
                <dl className="grid grid-cols-[1fr_auto] gap-y-1 text-sm">
                  <dt>Jobs awaiting allocation</dt>
                  <dd>{s?.operations.jobsAwaitingAllocation ?? 'not connected yet'}</dd>
                  <dt>Crew acknowledgements due</dt>
                  <dd>{s?.operations.acknowledgementsDue ?? 'not connected yet'}</dd>
                  <dt>Critical findings open</dt>
                  <dd>{s?.criticalOpen ?? '—'}</dd>
                </dl>
                <p className="mt-2 text-sm text-slate-700">
                  Critical findings remain visible until verified closed.
                </p>
              </section>
              {s && (
                <section
                  aria-labelledby="cov-h"
                  className="rounded border border-slate-300 bg-white p-4 text-sm"
                >
                  <h2 id="cov-h" className="mb-1 text-lg font-semibold">
                    Evidence coverage
                  </h2>
                  <p>
                    {s.coverage.percent === null
                      ? 'No applicable requirements.'
                      : `${s.coverage.percent}%`}{' '}
                    ({s.coverage.numerator} verified and current of {s.coverage.denominator}{' '}
                    applicable; {s.coverage.exclusions} not applicable excluded)
                  </p>
                  <p className="mt-1 font-semibold">{s.coverage.label}</p>
                </section>
              )}
            </div>
          </div>
          {s && (
            <p className="text-sm text-slate-700">
              Last refreshed{' '}
              {new Date(s.lastRefreshedAt).toLocaleString('en-GB', { timeZone: 'Europe/London' })}.{' '}
              {s.sources
                .filter((x: Row) => !x.ok)
                .map((x: Row) => `${words(x.name)} source not connected yet.`)
                .join(' ')}{' '}
              Internal measures on this dashboard are not CQC ratings.
            </p>
          )}
        </>
      )}
    </div>
  );
}
