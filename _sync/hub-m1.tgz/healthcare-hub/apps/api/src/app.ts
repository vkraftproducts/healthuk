import 'reflect-metadata';
import cors from '@fastify/cors';
import helmet from '@fastify/helmet';
import rateLimit from '@fastify/rate-limit';
import { NestFactory } from '@nestjs/core';
import { FastifyAdapter, type NestFastifyApplication } from '@nestjs/platform-fastify';
import { AppModule, type AppDeps } from './app.module.js';

/** Builds the configured Nest/Fastify app (shared by main.ts and tests). */
export async function createApp(deps: AppDeps): Promise<NestFastifyApplication> {
  const adapter = new FastifyAdapter({
    loggerInstance: deps.logger,
    trustProxy: true,
    bodyLimit: 1_048_576,
  });
  const app = await NestFactory.create<NestFastifyApplication>(AppModule.register(deps), adapter, {
    logger: false,
  });
  const fastify = app.getHttpAdapter().getInstance();
  await fastify.register(helmet, {
    contentSecurityPolicy: { directives: { defaultSrc: ["'none'"], frameAncestors: ["'none'"] } },
  });
  await fastify.register(cors, {
    origin: [deps.config.WEB_ORIGIN],
    credentials: true,
    allowedHeaders: [
      'Authorization',
      'Content-Type',
      'X-Org-Id',
      'X-Location-Id',
      'Idempotency-Key',
      'If-Match',
    ],
  });
  await fastify.register(rateLimit, {
    max: deps.config.NODE_ENV === 'test' ? 10_000 : 300,
    timeWindow: '1 minute',
    errorResponseBuilder: () => ({
      type: 'https://healthcare-hub.example/problems/rate-limited',
      title: 'Too many requests',
      status: 429,
      code: 'RATE_LIMITED',
    }),
  });
  app.setGlobalPrefix('api/v1', { exclude: ['healthz', 'readyz'] });
  return app;
}
