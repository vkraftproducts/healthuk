import { describe, expect, it } from 'vitest';
import { loadConfig } from '../src/config.js';

const base = {
  DATABASE_URL: 'postgresql://x',
  OIDC_ISSUER: 'https://login.example.test',
  OIDC_AUDIENCE: 'api',
  OIDC_JWKS_URI: 'https://login.example.test/jwks',
};

describe('config', () => {
  it('refuses a local/mock issuer in production', () => {
    expect(() =>
      loadConfig({
        ...base,
        NODE_ENV: 'production',
        OIDC_ISSUER: 'http://localhost:4010',
        IP_HASH_SECRET: 'x'.repeat(40),
      }),
    ).toThrow(/Mock\/local OIDC/);
  });
  it('requires a strong IP hash secret in production', () => {
    expect(() => loadConfig({ ...base, NODE_ENV: 'production' })).toThrow(/IP_HASH_SECRET/);
  });
  it('names invalid variables without printing their values', () => {
    try {
      loadConfig({ ...base, DATABASE_URL: '', API_PORT: 'secret-value' });
      expect.unreachable();
    } catch (e) {
      expect((e as Error).message).toMatch(/DATABASE_URL/);
      expect((e as Error).message).not.toContain('secret-value');
    }
  });
});
