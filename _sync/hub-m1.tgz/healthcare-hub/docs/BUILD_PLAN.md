# Build plan (work top to bottom; tick as you go)

Each milestone ends with: all tests green, demo script in `docs/demos/Mx.md`, and
DECISIONS.md updated. Do not start a milestone until the previous one is green.

## M0 — Foundations (Phase 2 start)

- [x] Monorepo (pnpm, Turborepo), TS strict, ESLint (incl. no-raw-prisma rule, no-console), Prettier, Husky + lint-staged, Conventional Commits
- [x] docker compose: postgres 16 (+btree_gist), azurite, mailpit, mock OIDC (dev only, hard-fails in prod) _(compose file written; Docker was unavailable in the build sandbox, so tests ran against a local Postgres 16. Mock OIDC runs as `pnpm --filter @hub/api dev:oidc`, not as a container.)_
- [x] `packages/config`, `packages/contracts` (zod + OpenAPI gen), `packages/db` (Prisma, raw SQL migration folder)
- [x] NestJS API skeleton: health `/healthz` `/readyz`, problem+json errors, pino with redaction, OTel _(OpenTelemetry export deferred to the Azure deployment; pino redaction done.)_
- [x] Auth guard (JWT via JWKS), `/me`, context interceptor, PermissionGuard + `@RequirePermission`
- [x] `withTenant()` + RLS policies + app/migrator DB roles; isolation test harness (TEST_PLAN §4)
- [x] Audit log module with hash chain + verify job _(hash chain + `/audit-log` + `verify-chain` done; the scheduled verify job and daily WORM anchor arrive with the worker in M2.)_
- [x] React web shell: layout, nav, breadcrumb/org switcher, auth flow, StatusBadge, DataTable _(auth flow uses the dev mock OIDC; Entra External ID PKCE is wired when the tenant exists.)_
- [x] GitHub Actions: lint, typecheck, unit, integration (testcontainers), build _(workflows written; not yet run on GitHub. Testcontainers not used: CI uses a postgres:16 service, see DECISIONS.)_
- [x] Bicep for staging (see ARCHITECTURE §5) + deploy workflow with OIDC federation _(written but NOT compiled or deployed: no Azure access yet. Run `az bicep build` and a what-if first.)_

## M1 — Organisation, users, roles, settings

- [x] Org/location/service/registered-activity CRUD; memberships; role/permission seed matrix
- [x] User invite, revoke (immediate), MFA enforcement for privileged roles
- [x] Support access grants (break-glass)
- [x] Settings screens; audit log viewer

> M1 notes: optimistic concurrency (If-Match → 409), invite via SECURITY DEFINER `invite_user()`, first sign-in links only on an IdP-verified email, break-glass grants ≤ 8h (read-only, audited per request), custom-role restrictions enforced in SQL and API, no privilege escalation (self-service permissions exempt). Org settings page edits only via API for now (warning windows UI arrives with M2 requirement templates).

## M2 — Rules engine + requirements + evidence

- [ ] `packages/rules`: date helpers, status evaluator, recurrence, readiness, validation (all RULES_ENGINE §8 vectors)
- [ ] Requirement templates/versions (publish flow), instances, applicability, due-date changes
- [ ] Evidence upload via SAS → quarantine → scan → evidence; verification; many-to-many links
- [ ] Reconciler worker (pg-boss) + status snapshot table
- [ ] Alerts + notification delivery (email via ACS, dedupe, retry, deputy escalation)

## M3 — Staff module (wireframe 02)

- [ ] Staff list/profile with tabs; lifecycle transitions; role approvals; restrictions
- [ ] Recruitment, references, DBS (restricted), RTW, licences, registrations, OH status
- [ ] Training matrix by role, competencies, supervision, appraisal; role change recalculation
- [ ] Self-service uploads & correction requests; dispatcher-limited view

## M4 — Fleet & equipment

- [ ] Vehicle register, documents as requirements, location history, odometer with flags
- [ ] Maintenance by date/mileage; equipment register; inspection regimes; quarantine
- [ ] VDI templates + submissions (immutable + amendments); cleaning records
- [ ] Defects with automatic blocking + affected jobs; return-to-service; fuel/expenses + export

## M5 — Dashboard (wireframe 01) + compliance (wireframe 03)

- [ ] Dashboard summary/actions/export; filters; source health; reconciliation test (UAT-08)
- [ ] Audit templates/versions, runs, sampling, responses, findings, actions, verification, re-audit
- [ ] Policies/SOPs lifecycle + acknowledgements; risk register; registration & correspondence
- [ ] Events, reporting obligations, candour, complaints; premises register
- [ ] Seed AC-01..AC-11 as inactive templates; Ambulance pack v1 starter library (inactive until approved)
- [ ] Evidence pack export (PDF index + ZIP) via worker

## M6 — Work planner & dispatch (wireframe 04) (Phase 3)

- [ ] Bookings, recurrence series with instance edits, job fields with minimisation
- [ ] Shifts, crew assignments, resource_booking exclusion constraint
- [ ] Validate/allocate endpoints, validation panel UI, policy exceptions (no statutory/safety overrides)
- [ ] Planner day/week grid with drag/drop + keyboard alternative
- [ ] Job lifecycle, offers/acknowledgements, late/unacknowledged alerts, reassignment on block

## M7 — Crew app (wireframe 05)

- [ ] Expo app scaffolding, auth, secure storage, encrypted DB, outbox sync
- [ ] My shift + gates, VDI, cleaning, job detail/progress, defects, fuel, policies, profile
- [ ] Push registration (generic payloads); revocation wipe; offline rules
- [ ] Maestro E2E flows; EAS internal builds

## M8 — Reports, import, hardening, go-live readiness (Phases 4–5)

- [ ] Reports listed in PRD §4.10 with documented definitions; monthly management pack PDF
- [ ] CSV import framework + compliance workbook staging per MIG-01..03; full data export
- [ ] Retention rules, legal hold, SAR export, breach record workflow
- [ ] Production Bicep (prod params), budgets & alerts, backup geo-redundancy, restore runbook + drill
- [ ] k6 load test at pilot profile; axe accessibility pass; ZAP baseline; pen-test fixes
- [ ] Compliance artefacts (SECURITY_COMPLIANCE §9); admin & user guides in `docs/guides/`
- [ ] All UAT-01..08 green; no open critical safety/isolation defects

## Later (separately approved): Phase 4 sector packs

Dental pack, care-home pack (content requires specialist validation), integrations
(FleetX, payroll, telematics, calendars) via adapters in `apps/api/src/integrations/*`.
