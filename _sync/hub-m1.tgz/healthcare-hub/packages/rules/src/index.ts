// Pure, deterministic status/date/gate logic (docs/RULES_ENGINE.md) - no I/O, `now` is always an
// explicit argument. Implemented in Milestone M2 with 100% branch coverage; web, API, worker and
// mobile all import this package so the rules are identical everywhere.
export const RULES_PACKAGE = '@hub/rules' as const;
