import pg from 'pg';

// Synthetic data only (CLAUDE.md #10). Matches the wireframes: "Example organisation / Watford"
// plus a second organisation used by isolation tests. Fixed IDs make the seed idempotent.
// Runs as the migrator role; sets the org context itself because RLS is FORCEd.
// Requires migrations (which sync the system roles) to have run first.

export const SEED_IDS = {
  orgExample: '01900000-0000-7000-8000-000000000001',
  orgOther: '01900000-0000-7000-8000-000000000002',
  locWatford: '01900000-0000-7000-8000-000000000011',
  locOther: '01900000-0000-7000-8000-000000000012',
} as const;

interface SeedUser {
  id: string;
  subject: string;
  email: string;
  name: string;
  org: string;
  role: string;
}

const u = (n: number) => `01900000-0000-7000-8000-0000000001${String(n).padStart(2, '0')}`;
export const SEED_USERS: Record<string, SeedUser> = {
  manager: {
    id: u(1),
    subject: 'dev|manager',
    email: 'manager@example.test',
    name: 'Dev Manager',
    org: SEED_IDS.orgExample,
    role: 'REGISTERED_MANAGER',
  },
  hr: {
    id: u(2),
    subject: 'dev|hr',
    email: 'hr@example.test',
    name: 'Hana Rowe',
    org: SEED_IDS.orgExample,
    role: 'HR_LEAD',
  },
  dispatcher: {
    id: u(3),
    subject: 'dev|dispatcher',
    email: 'dispatcher@example.test',
    name: 'Dev Dispatcher',
    org: SEED_IDS.orgExample,
    role: 'DISPATCHER',
  },
  fleet: {
    id: u(4),
    subject: 'dev|fleet',
    email: 'fleet@example.test',
    name: 'Finn Lee',
    org: SEED_IDS.orgExample,
    role: 'FLEET_LEAD',
  },
  governance: {
    id: u(5),
    subject: 'dev|governance',
    email: 'governance@example.test',
    name: 'Gina Ode',
    org: SEED_IDS.orgExample,
    role: 'GOVERNANCE_LEAD',
  },
  admin: {
    id: u(6),
    subject: 'dev|admin',
    email: 'admin@example.test',
    name: 'Ola Admin',
    org: SEED_IDS.orgExample,
    role: 'ORG_ADMIN',
  },
  crew: {
    id: u(7),
    subject: 'dev|crew',
    email: 'crew@example.test',
    name: 'Alex Morgan',
    org: SEED_IDS.orgExample,
    role: 'CREW',
  },
  crew2: {
    id: u(8),
    subject: 'dev|crew2',
    email: 'crew2@example.test',
    name: 'Sam Taylor',
    org: SEED_IDS.orgExample,
    role: 'CREW',
  },
  auditor: {
    id: u(9),
    subject: 'dev|auditor',
    email: 'auditor@example.test',
    name: 'Audrey Ward',
    org: SEED_IDS.orgExample,
    role: 'AUDITOR',
  },
  otherManager: {
    id: u(21),
    subject: 'dev|other-manager',
    email: 'other.manager@example.test',
    name: 'Other Manager',
    org: SEED_IDS.orgOther,
    role: 'REGISTERED_MANAGER',
  },
  otherCrew: {
    id: u(22),
    subject: 'dev|other-crew',
    email: 'other.crew@example.test',
    name: 'Other Crew',
    org: SEED_IDS.orgOther,
    role: 'CREW',
  },
};

export const SEED_SUPPORT = {
  id: u(10),
  subject: 'dev|support',
  email: 'support@example.test',
  name: 'Platform Support',
} as const;

export async function seed(adminUrl: string): Promise<void> {
  const c = new pg.Client({ connectionString: adminUrl });
  await c.connect();
  try {
    await c.query('BEGIN');
    const ctx = (org: string) => c.query(`SELECT set_config('app.org_id', $1, true)`, [org]);
    const orgs: [string, string, string[], string, string, boolean][] = [
      [
        SEED_IDS.orgExample,
        'Example organisation',
        ['ambulance'],
        SEED_IDS.locWatford,
        'Watford',
        true,
      ],
      [SEED_IDS.orgOther, 'Other organisation', [], SEED_IDS.locOther, 'Elsewhere', false],
    ];
    for (const [id, name, packs, loc, locName, registered] of orgs) {
      await ctx(id);
      await c.query(
        `INSERT INTO organisation (id, name, sector_packs) VALUES ($1, $2, $3) ON CONFLICT (id) DO NOTHING`,
        [id, name, packs],
      );
      await c.query(
        `INSERT INTO location (id, organisation_id, name, registered) VALUES ($1, $2, $3, $4) ON CONFLICT (id) DO NOTHING`,
        [loc, id, locName, registered],
      );
      for (const user of Object.values(SEED_USERS).filter((x) => x.org === id)) {
        await c.query(
          `INSERT INTO app_user (id, idp_subject, email, display_name, status) VALUES ($1, $2, $3, $4, 'ACTIVE')
           ON CONFLICT (id) DO NOTHING`,
          [user.id, user.subject, user.email, user.name],
        );
        const role = await c.query(
          `SELECT id FROM role WHERE organisation_id IS NULL AND key = $1`,
          [user.role],
        );
        if (!role.rowCount)
          throw new Error(`System role ${user.role} missing: run migrations first`);
        await c.query(
          `INSERT INTO membership (organisation_id, user_id, role_id)
           SELECT $1, $2, $3 WHERE NOT EXISTS (SELECT 1 FROM membership WHERE organisation_id = $1 AND user_id = $2)`,
          [id, user.id, role.rows[0].id],
        );
      }
      await c.query(
        `INSERT INTO service_type (organisation_id, code, name) VALUES ($1, 'PTS', 'Patient transport service')
         ON CONFLICT DO NOTHING`,
        [id],
      );
    }
    await c.query(
      `INSERT INTO app_user (id, idp_subject, email, display_name, status, is_platform_support)
       VALUES ($1, $2, $3, $4, 'ACTIVE', true) ON CONFLICT (id) DO NOTHING`,
      [SEED_SUPPORT.id, SEED_SUPPORT.subject, SEED_SUPPORT.email, SEED_SUPPORT.name],
    );
    await c.query('COMMIT');
  } catch (e) {
    await c.query('ROLLBACK');
    throw e;
  } finally {
    await c.end();
  }
}
