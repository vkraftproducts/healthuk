import { z } from 'zod';
import { AuditListResponse, VerifyChainResponse } from './audit.js';
import { HealthResponse, ReadyResponse } from './health.js';
import { MeResponse } from './me.js';
import { Problem } from './problem.js';
import {
  ActivityDto,
  AdminUserDto,
  LocationDto,
  OrganisationDto,
  PermissionDto,
  RoleDto,
  ServiceDto,
  SettingsResponse,
  SupportGrantDto,
} from './admin.js';
import { z as zz } from 'zod';
import { uuid } from './common.js';

const list = <T extends zz.ZodType>(t: T) => zz.object({ data: zz.array(t) });

export interface RouteDef {
  method: 'get' | 'post' | 'patch' | 'delete';
  path: string; // relative to /api/v1 unless `unversioned`
  summary: string;
  response: z.ZodType;
  unversioned?: boolean;
  public?: boolean;
}

/** Registry used to generate OpenAPI. Add every endpoint here with its zod schemas. */
export const routes: Record<string, RouteDef> = {
  healthz: {
    method: 'get',
    path: '/healthz',
    summary: 'Liveness',
    response: HealthResponse,
    unversioned: true,
    public: true,
  },
  readyz: {
    method: 'get',
    path: '/readyz',
    summary: 'Readiness',
    response: ReadyResponse,
    unversioned: true,
    public: true,
  },
  me: {
    method: 'get',
    path: '/me',
    summary: 'Current user, memberships and permissions',
    response: MeResponse,
  },
  orgGet: {
    method: 'get',
    path: '/organisations/{id}',
    summary: 'Get the organisation',
    response: OrganisationDto,
  },
  orgPatch: {
    method: 'patch',
    path: '/organisations/{id}',
    summary: 'Update the organisation (If-Match)',
    response: OrganisationDto,
  },
  locationsList: {
    method: 'get',
    path: '/organisations/{id}/locations',
    summary: 'List locations in scope',
    response: list(LocationDto),
  },
  locationsCreate: {
    method: 'post',
    path: '/organisations/{id}/locations',
    summary: 'Create a location',
    response: LocationDto,
  },
  locationsPatch: {
    method: 'patch',
    path: '/organisations/{id}/locations/{locationId}',
    summary: 'Update or archive a location (If-Match)',
    response: LocationDto,
  },
  servicesList: {
    method: 'get',
    path: '/organisations/{id}/services',
    summary: 'List service types',
    response: list(ServiceDto),
  },
  servicesCreate: {
    method: 'post',
    path: '/organisations/{id}/services',
    summary: 'Create a service type',
    response: ServiceDto,
  },
  servicesPatch: {
    method: 'patch',
    path: '/organisations/{id}/services/{serviceId}',
    summary: 'Update a service type (If-Match)',
    response: ServiceDto,
  },
  activitiesList: {
    method: 'get',
    path: '/organisations/{id}/registered-activities',
    summary: 'List registered activities',
    response: list(ActivityDto),
  },
  activitiesCreate: {
    method: 'post',
    path: '/organisations/{id}/registered-activities',
    summary: 'Create a registered activity',
    response: ActivityDto,
  },
  activitiesPatch: {
    method: 'patch',
    path: '/organisations/{id}/registered-activities/{activityId}',
    summary: 'Update a registered activity (If-Match)',
    response: ActivityDto,
  },
  adminUsers: {
    method: 'get',
    path: '/admin/users',
    summary: 'List users with access to the organisation',
    response: list(AdminUserDto),
  },
  adminInvite: {
    method: 'post',
    path: '/admin/users',
    summary: 'Invite a user with a role',
    response: zz.object({ id: uuid }),
  },
  adminAddMembership: {
    method: 'post',
    path: '/admin/users/{id}/memberships',
    summary: 'Add a role/location membership',
    response: zz.object({ membershipId: uuid }),
  },
  adminRevoke: {
    method: 'post',
    path: '/admin/users/{id}/revoke',
    summary: 'Revoke access immediately',
    response: zz.object({ revokedMemberships: zz.number(), revokedDevices: zz.number() }),
  },
  adminPermissions: {
    method: 'get',
    path: '/admin/permissions',
    summary: 'Permission catalogue',
    response: list(PermissionDto),
  },
  adminRoles: {
    method: 'get',
    path: '/admin/roles',
    summary: 'List system and custom roles',
    response: list(RoleDto),
  },
  adminRoleCreate: {
    method: 'post',
    path: '/admin/roles',
    summary: 'Create a custom role',
    response: RoleDto,
  },
  adminRolePatch: {
    method: 'patch',
    path: '/admin/roles/{id}',
    summary: 'Update a custom role (If-Match)',
    response: RoleDto,
  },
  adminSettings: {
    method: 'get',
    path: '/admin/settings',
    summary: 'Organisation settings',
    response: SettingsResponse,
  },
  adminSettingsPatch: {
    method: 'patch',
    path: '/admin/settings',
    summary: 'Update settings (If-Match)',
    response: SettingsResponse,
  },
  supportGrants: {
    method: 'get',
    path: '/admin/support-access-grants',
    summary: 'List break-glass grants',
    response: list(SupportGrantDto),
  },
  supportGrantCreate: {
    method: 'post',
    path: '/admin/support-access-grants',
    summary: 'Approve time-limited support access',
    response: SupportGrantDto,
  },
  auditList: {
    method: 'get',
    path: '/audit-log',
    summary: 'Audit log (admin.audit.view)',
    response: AuditListResponse,
  },
  auditVerify: {
    method: 'post',
    path: '/audit-log/verify-chain',
    summary: 'Verify the audit hash chain (admin.audit.verify)',
    response: VerifyChainResponse,
  },
};

export function buildOpenApi(version = '0.0.0') {
  const paths: Record<string, Record<string, unknown>> = {};
  for (const r of Object.values(routes)) {
    const full = r.unversioned ? r.path : `/api/v1${r.path}`;
    paths[full] ??= {};
    paths[full][r.method] = {
      summary: r.summary,
      security: r.public ? [] : [{ bearer: [] }],
      parameters: r.public
        ? []
        : [
            {
              name: 'X-Org-Id',
              in: 'header',
              required: false,
              schema: { type: 'string', format: 'uuid' },
            },
          ],
      responses: {
        '200': {
          description: 'OK',
          content: { 'application/json': { schema: z.toJSONSchema(r.response) } },
        },
        default: {
          description: 'Error (RFC 9457 problem+json)',
          content: { 'application/problem+json': { schema: z.toJSONSchema(Problem) } },
        },
      },
    };
  }
  return {
    openapi: '3.1.0',
    info: { title: 'Healthcare Hub API', version },
    components: {
      securitySchemes: { bearer: { type: 'http', scheme: 'bearer', bearerFormat: 'JWT' } },
    },
    paths,
  };
}
