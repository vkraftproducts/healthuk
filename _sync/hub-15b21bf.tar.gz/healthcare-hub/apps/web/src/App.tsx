import {
  RouterProvider,
  createMemoryHistory,
  createRootRoute,
  createRoute,
  createRouter,
  type RouterHistory,
} from '@tanstack/react-router';
import {
  QueryClient,
  QueryClientProvider,
  keepPreviousData,
  useQuery,
} from '@tanstack/react-query';
import { useCallback, useMemo, useState } from 'react';
import type { ApiClient } from './api.js';
import { NAV_ITEMS } from './nav.js';
import { ComingSoon } from './pages/ComingSoon.js';
import { Dashboard } from './pages/Dashboard.js';
import { Settings } from './pages/settings/Settings.js';
import { StaffList } from './pages/staff/StaffList.js';
import { StaffProfile } from './pages/staff/StaffProfile.js';
import { Fleet } from './pages/fleet/Fleet.js';
import { VehicleDetail } from './pages/fleet/VehicleDetail.js';
import { Compliance } from './pages/compliance/Compliance.js';
import { AuditRun } from './pages/compliance/AuditRun.js';
import { Premises } from './pages/premises/Premises.js';
import { Planner } from './pages/planner/Planner.js';
import { Reports } from './pages/reports/Reports.js';
import { AppContext } from './shell/AppContext.js';
import { Shell } from './shell/Shell.js';

/** Page for each top-level navigation item; anything not listed shows a "coming later" page. */
const PAGES: Record<string, () => JSX.Element> = {
  '/settings': Settings,
  '/staff': StaffList,
  '/vehicles': Fleet,
  '/compliance': Compliance,
  '/premises': Premises,
  '/planner': Planner,
  '/reports': Reports,
};

function buildRouter(history?: RouterHistory) {
  const root = createRootRoute({ component: Shell });
  const index = createRoute({ getParentRoute: () => root, path: '/', component: Dashboard });
  const others = NAV_ITEMS.filter((n) => n.to !== '/').map((n) =>
    createRoute({
      getParentRoute: () => root,
      path: n.to,
      component: PAGES[n.to] ?? (() => <ComingSoon title={n.label} milestone="later" />),
    }),
  );
  const staffProfile = createRoute({
    getParentRoute: () => root,
    path: '/staff/$id',
    component: StaffProfile,
  });
  const vehicleDetail = createRoute({
    getParentRoute: () => root,
    path: '/vehicles/$id',
    component: VehicleDetail,
  });
  const auditRun = createRoute({
    getParentRoute: () => root,
    path: '/compliance/audits/$id',
    component: AuditRun,
  });
  return createRouter({
    routeTree: root.addChildren([index, ...others, staffProfile, vehicleDetail, auditRun]),
    history,
  });
}

function Authenticated({ api, history }: { api: ApiClient; history?: RouterHistory }) {
  const [orgId, setOrgIdState] = useState<string | null>(() => {
    try {
      return sessionStorage.getItem('hub.orgId');
    } catch {
      return null;
    }
  });
  const setOrgId = useCallback((id: string) => {
    setOrgIdState(id);
    try {
      sessionStorage.setItem('hub.orgId', id);
    } catch {
      /* storage unavailable: selection lives in memory only */
    }
  }, []);

  const meQ = useQuery({
    queryKey: ['me', orgId],
    queryFn: () => api.me(orgId),
    retry: false,
    placeholderData: keepPreviousData,
  });
  const readyQ = useQuery({
    queryKey: ['readyz'],
    queryFn: () => api.readyz(),
    retry: false,
    refetchInterval: 60_000,
  });
  const router = useMemo(() => buildRouter(history), [history]);

  // Default to the first membership; drop a stale selection the server no longer accepts.
  const me = meQ.data;
  const effectiveOrg = orgId ?? me?.memberships[0]?.organisationId ?? null;
  if (me && !orgId && effectiveOrg) queueMicrotask(() => setOrgId(effectiveOrg));

  if (meQ.isError) {
    return (
      <div role="alert" className="m-6 rounded border border-red-700 bg-red-50 p-4 text-red-900">
        <strong>Source unavailable.</strong> Could not load your account. Check your connection and
        sign in again.
      </div>
    );
  }
  if (!me)
    return (
      <p role="status" className="m-6">
        Loading…
      </p>
    );

  const lastUpdated = meQ.dataUpdatedAt ? new Date(meQ.dataUpdatedAt) : null;
  return (
    <AppContext.Provider
      value={{
        api,
        me,
        orgId: effectiveOrg,
        setOrgId,
        refresh: () => {
          void meQ.refetch();
          void readyQ.refetch();
        },
        lastUpdated,
        sourceOk: readyQ.data?.status === 'ready',
      }}
    >
      <RouterProvider router={router} />
    </AppContext.Provider>
  );
}

export function App({
  api,
  history = createMemoryHistoryIfNeeded(),
}: {
  api: ApiClient;
  history?: RouterHistory;
}) {
  const [client] = useState(() => new QueryClient());
  return (
    <QueryClientProvider client={client}>
      <Authenticated api={api} history={history} />
    </QueryClientProvider>
  );
}

function createMemoryHistoryIfNeeded(): RouterHistory | undefined {
  return typeof window === 'undefined' ? createMemoryHistory({ initialEntries: ['/'] }) : undefined;
}
