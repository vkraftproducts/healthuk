import { z } from 'zod';

const Env = z.object({
  NODE_ENV: z.enum(['development', 'test', 'production']).default('development'),
  API_PORT: z.coerce.number().int().default(4000),
  DATABASE_URL: z.string().min(1),
  OIDC_ISSUER: z.string().url(),
  OIDC_AUDIENCE: z.string().min(1),
  OIDC_JWKS_URI: z.string().url(),
  WEB_ORIGIN: z.string().url().default('http://localhost:5173'),
  IP_HASH_SECRET: z.string().min(16).default('dev-only-ip-hash-secret-change-me'),
  PUBLIC_API_URL: z.string().url().default('http://localhost:4000'),
  EVIDENCE_DIR: z.string().min(1).default('./.data/evidence'),
  BLOB_SIGNING_SECRET: z.string().min(16).default('dev-only-blob-signing-secret-change-me'),
  LOG_LEVEL: z.enum(['silent', 'fatal', 'error', 'warn', 'info', 'debug', 'trace']).default('info'),
});

export type AppConfig = z.infer<typeof Env>;
export const CONFIG = Symbol('CONFIG');

export function loadConfig(env: Record<string, string | undefined> = process.env): AppConfig {
  const parsed = Env.safeParse(env);
  if (!parsed.success) {
    // Names only: never print values (they may be secrets).
    const names = parsed.error.issues.map((i) => i.path.join('.')).join(', ');
    throw new Error(`Invalid configuration: ${names}`);
  }
  const cfg = parsed.data;
  if (cfg.NODE_ENV === 'production' && /localhost|127\.0\.0\.1/.test(cfg.OIDC_ISSUER)) {
    throw new Error('Mock/local OIDC issuer is not permitted in production');
  }
  if (cfg.NODE_ENV === 'production' && (!env.IP_HASH_SECRET || env.IP_HASH_SECRET.length < 32)) {
    throw new Error('IP_HASH_SECRET (>= 32 chars) is required in production');
  }
  if (
    cfg.NODE_ENV === 'production' &&
    (!env.BLOB_SIGNING_SECRET || env.BLOB_SIGNING_SECRET.length < 32)
  ) {
    throw new Error('BLOB_SIGNING_SECRET (>= 32 chars) is required in production');
  }
  return cfg;
}
